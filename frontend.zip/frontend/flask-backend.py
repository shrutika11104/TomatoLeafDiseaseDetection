from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import numpy as np
from werkzeug.utils import secure_filename
from PIL import Image
import io
import tensorflow as tf
import time

# Initialize Flask app
app = Flask(__name__, static_folder='static')
CORS(app)  # Allow cross-origin requests

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MODEL_PATH = 'model/tomato_disease_model.h5'  # Path to your saved model
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB max upload

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Disease classes
CLASSES = [
    'Tomato_Bacterial_spot',
    'Tomato_Early_blight',
    'Tomato_Late_blight',
    'Tomato_Leaf_Mold',
    'Tomato_Septoria_leaf_spot',
    'Tomato_Spider_mites',
    'Tomato_Target_Spot',
    'Tomato_mosaic_virus',
    'Tomato_Yellow_Leaf_Curl_Virus',
    'Tomato_healthy'
]

# Disease information database (same as in your frontend)
disease_info = {
    "Tomato_Bacterial_spot": {
        "name": "Bacterial Spot",
        "description": "A serious bacterial disease that affects tomatoes in warm, wet conditions. It causes dark, water-soaked, circular spots on leaves, stems, and fruits.",
        "management": [
            "Use disease-free seeds and transplants",
            "Apply copper-based bactericides preventatively",
            "Avoid overhead irrigation",
            "Rotate crops with non-host plants",
            "Remove and destroy infected plant material"
        ]
    },
    "Tomato_Early_blight": {
        "name": "Early Blight",
        "description": "A fungal disease that produces distinctive dark spots with concentric rings forming a 'bull's eye' pattern on lower, older leaves first.",
        "management": [
            "Remove lower infected leaves",
            "Apply fungicides preventatively",
            "Mulch around plants to prevent soil splash",
            "Ensure good air circulation between plants",
            "Practice crop rotation"
        ]
    },
    "Tomato_Late_blight": {
        "name": "Late Blight",
        "description": "A devastating water mold infection that causes large, dark, water-soaked lesions on leaves, stems, and fruits, especially in cool, wet weather.",
        "management": [
            "Apply fungicides preventatively before disease appears",
            "Remove and destroy infected plants immediately",
            "Avoid overhead irrigation",
            "Plant resistant varieties when available",
            "Ensure good air circulation"
        ]
    },
    "Tomato_Leaf_Mold": {
        "name": "Leaf Mold",
        "description": "A fungal disease common in humid environments that causes pale green or yellow spots on the upper leaf surface with olive-green to grayish mold on the lower surface.",
        "management": [
            "Improve greenhouse ventilation",
            "Avoid leaf wetness by using drip irrigation",
            "Apply fungicides when symptoms first appear",
            "Remove and destroy infected plant material",
            "Space plants for good air circulation"
        ]
    },
    "Tomato_Septoria_leaf_spot": {
        "name": "Septoria Leaf Spot",
        "description": "A fungal disease characterized by numerous small circular spots with dark borders and light gray or tan centers, primarily on lower leaves.",
        "management": [
            "Remove infected leaves immediately",
            "Apply fungicides preventatively",
            "Use mulch to prevent spore splash",
            "Ensure adequate plant spacing",
            "Avoid overhead watering"
        ]
    },
    "Tomato_Spider_mites": {
        "name": "Spider Mites",
        "description": "Tiny arachnids that cause stippling (small yellow/white spots) on leaves and fine webbing between leaves and stems, especially in hot, dry conditions.",
        "management": [
            "Increase humidity around plants",
            "Spray plants with water to dislodge mites",
            "Apply insecticidal soap or horticultural oil",
            "Introduce predatory mites",
            "Avoid drought stress"
        ]
    },
    "Tomato_Target_Spot": {
        "name": "Target Spot",
        "description": "A fungal disease that creates dark brown, concentric rings on leaves, stems, and fruits, resembling targets or bullseyes.",
        "management": [
            "Apply appropriate fungicides",
            "Remove infected plant parts",
            "Maintain adequate plant spacing",
            "Avoid overhead irrigation",
            "Practice crop rotation"
        ]
    },
    "Tomato_mosaic_virus": {
        "name": "Mosaic Virus",
        "description": "A viral disease that causes mottled light and dark green patterns on leaves, with possible leaf distortion and stunted plant growth.",
        "management": [
            "Remove and destroy infected plants",
            "Wash hands and tools after handling infected plants",
            "Control insect vectors like aphids",
            "Plant resistant varieties",
            "There is no chemical treatment available"
        ]
    },
    "Tomato_Yellow_Leaf_Curl_Virus": {
        "name": "Yellow Leaf Curl Virus",
        "description": "A viral disease transmitted by whiteflies that causes leaf edges to curl upward and inward, with leaves becoming yellow, small, and distorted.",
        "management": [
            "Control whitefly populations",
            "Use reflective mulches to repel whiteflies",
            "Plant resistant varieties",
            "Install insect-proof screens in greenhouses",
            "Remove and destroy infected plants"
        ]
    },
    "Tomato_healthy": {
        "name": "Healthy",
        "description": "No disease is present. The tomato plant displays normal, vibrant green leaves without spots, discoloration, or deformities.",
        "management": [
            "Maintain regular watering schedule",
            "Fertilize appropriately",
            "Ensure good air circulation",
            "Monitor regularly for early signs of pests or disease",
            "Provide adequate sunlight"
        ]
    }
}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Load model - commented out until we have an actual model
# try:
#     model = tf.keras.models.load_model(MODEL_PATH)
#     print("Model loaded successfully!")
# except Exception as e:
#     print(f"Error loading model: {e}")
#     model = None

def preprocess_image(image_bytes, target_size=(224, 224)):
    """Preprocess the image for model prediction"""
    img = Image.open(io.BytesIO(image_bytes))
    img = img.resize(target_size)
    img = img.convert('RGB')
    img_array = np.array(img) / 255.0  # Normalize pixel values
    img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
    return img_array

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/classify', methods=['POST'])
def classify_image():
    # Check if image was sent in request
    if 'image' not in request.files:
        return jsonify({'error': 'No image part in the request'}), 400
    
    file = request.files['image']
    
    # Check if file is selected
    if file.filename == '':
        return jsonify({'error': 'No image selected'}), 400
    
    # Check if file is allowed
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Read the image file
        with open(filepath, 'rb') as f:
            img_bytes = f.read()
        
        # Since we don't have an actual model yet, we'll simulate the prediction
        # In a real app, we would use the model to make predictions
        # img_array = preprocess_image(img_bytes)
        # predictions = model.predict(img_array)[0]
        
        # Simulate prediction processing time
        time.sleep(1.5)
        
        # Simulate predictions (random confidences)
        # In a real app, replace this with actual model predictions
        np.random.seed(int(time.time()))  # Use current time for random seed
        predictions = np.random.random(len(CLASSES))
        predictions = predictions / np.sum(predictions)  # Normalize to sum to 1
        
        # Convert predictions to list of (class, confidence) tuples
        pred_list = [(CLASSES[i], float(predictions[i])) for i in range(len(CLASSES))]
        
        # Sort by confidence (descending)
        pred_list.sort(key=lambda x: x[1], reverse=True)
        
        # Get top prediction
        top_pred_class, top_confidence = pred_list[0]
        
        # Prepare result
        result = {
            'predictions': [{'disease': c, 'confidence': float(conf)} for c, conf in pred_list],
            'top_prediction': {
                'disease': top_pred_class,
                'name': disease_info[top_pred_class]['name'],
                'confidence': float(top_confidence),
                'description': disease_info[top_pred_class]['description'],
                'management': disease_info[top_pred_class]['management']
            }
        }
        
        return jsonify(result)
    
    return jsonify({'error': 'Invalid file format. Only JPG and PNG are allowed.'}), 400

# Serve static files
@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
