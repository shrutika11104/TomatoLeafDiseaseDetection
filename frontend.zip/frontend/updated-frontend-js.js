// Keep the existing event listeners for the upload area and UI elements

// Update the classify button click event handler
classifyBtn.addEventListener('click', () => {
    // Show loading state
    classifyBtn.disabled = true;
    classifyBtn.textContent = 'Classifying...';
    
    // Get the uploaded file
    const fileInput = document.getElementById('file-input');
    if (!fileInput.files || fileInput.files.length === 0) {
        alert('Please select an image first');
        classifyBtn.textContent = 'Classify Image';
        classifyBtn.disabled = false;
        return;
    }
    
    const file = fileInput.files[0];
    
    // Create form data to send to server
    const formData = new FormData();
    formData.append('image', file);
    
    // Send request to Flask backend
    fetch('http://localhost:5000/classify', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        // Display results
        document.getElementById('prediction-result').textContent = data.top_prediction.name;
        const confidencePercent = (data.top_prediction.confidence * 100).toFixed(2);
        document.getElementById('confidence-result').textContent = `${confidencePercent}%`;
        document.getElementById('confidence-bar').style.width = `${confidencePercent}%`;
        
        // Fill the predictions table
        const tableBody = document.querySelector('#predictions-table tbody');
        tableBody.innerHTML = '';
        
        data.predictions.forEach(pred => {
            const row = document.createElement('tr');
            const diseaseCell = document.createElement('td');
            const confidenceCell = document.createElement('td');
            
            diseaseCell.textContent = diseaseInfo[pred.disease].name;
            confidenceCell.textContent = `${(pred.confidence * 100).toFixed(2)}%`;
            
            row.appendChild(diseaseCell);
            row.appendChild(confidenceCell);
            tableBody.appendChild(row);
        });
        
        // Show disease info
        const diseaseInfoDiv = document.getElementById('disease-info');
        diseaseInfoDiv.style.display = 'block';
        
        const diseaseDetails = document.getElementById('disease-details');
        diseaseDetails.innerHTML = `
            <h4>${data.top_prediction.name}</h4>
            <p>${data.top_prediction.description}</p>
            <h4>Management Recommendations:</h4>
            <ul>
                ${data.top_prediction.management.map(tip => `<li>${tip}</li>`).join('')}
            </ul>
        `;
        
        // Show results
        resultContainer.style.display = 'block';
        
        // Initialize charts if they're in the viewport
        initializeCharts();
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error classifying image. Please try again.');
    })
    .finally(() => {
        // Reset button state
        classifyBtn.textContent = 'Classify Image';
        classifyBtn.disabled = false;
    });
});

// Keep the rest of your JavaScript code for chart initialization, etc.
