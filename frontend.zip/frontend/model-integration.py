# model_setup.py
# Script to download and prepare a pre-trained model for tomato leaf disease classification

import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model
import os

def create_pretrained_model(num_classes=10):
    """Create a pre-trained model based on MobileNetV2"""
    # Load the MobileNetV2 model pre-trained on ImageNet
    base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
    
    # Freeze the base model layers
    for layer in base_model.layers:
        layer.trainable = False
    
    # Add custom classification head
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dense(128, activation='relu')(x)
    predictions = Dense(num_classes, activation='softmax')(x)
    
    # Create the model
    model = Model(inputs=base_model.input, outputs=predictions)
    
    # Compile the model
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model

def main():
    # Create model directory if it doesn't exist
    os.makedirs('model', exist_ok=True)
    
    # Create the model
    print("Creating pre-trained model...")
    model = create_pretrained_model()
    
    # Save the model
    model_path = 'model/tomato_disease_model.h5'
    print(f"Saving model to {model_path}...")
    model.save(model_path)
    print("Model saved successfully!")

if __name__ == "__main__":
    main()
